  Hello Guys Chai Pilo.


  📌 Project Name: Travel Guide – City Guide Website
  🖥️ Main Page: index.html
  👨‍💻 Develop By: ayush_less



  🔍 Objective
  Indore, Ujjain aur Bhopal ke famous jagah dikhane ke liye banayi hai. Jese – Rajwada, Mahakal, Bhojtal, Bharat Bhavan, Chappan Dukan, Kal Bhairav, etc.



  Har jagah ke liye:
  📸 Photos
  📖 Thoda sa description
  🎥 YouTube video
  🗺️ Google map link



  🔥 Features ?

  Har city ka alag page

  Responsive design (mobile pe bhi mast dikhega)

  Suggested video section

  Contact form (seedha Gmail pe aata hai)

  Navigation easy hai



  📁 Important files:

  index.html → Main home page

  indore.html, ujjain.html, bhopal.html → City pages

  contact.html → Form jaha se log msg bhej sakte

  Baaki jagah ke individual pages bhi hai



  📬 Contact Us
  Email : asuraj0789@gmail.com
  Mobile number : XXXXXX6225